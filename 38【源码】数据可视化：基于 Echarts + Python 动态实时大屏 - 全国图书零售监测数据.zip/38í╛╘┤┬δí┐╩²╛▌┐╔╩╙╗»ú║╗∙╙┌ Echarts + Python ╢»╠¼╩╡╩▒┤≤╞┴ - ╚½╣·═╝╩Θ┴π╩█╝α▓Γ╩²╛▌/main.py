# -*- coding:utf-8 -*-

import io
import os
import sys
import time
import urllib
import random
import json
from flask import Flask, redirect
# 导入线程模块
import threading

app = Flask(__name__, static_folder="static", template_folder="template")


@app.route('/')
def index():
    return redirect('/static/index.html')

@app.route('/get_mdata')
def get_mdata():
    jsonData = {}
    jsonData['book'] = random.randint(100, 10000)
    jsonData['variety'] = random.randint(100, 10000)
    jsonData['sales'] = random.randint(100, 10000)
    jsonData['stock'] = random.randint(100, 10000)
    jsonData['id'] = random.randint(100, 10000)
    return json.dumps(jsonData)


def loop():
    time.sleep(10)
    pass

# 主程序在这里
if __name__ == "__main__":
    a = threading.Thread(target=loop)
    a.start()

    # 开启 flask 服务
    app.run(host='127.0.0.1', port=80, debug=True)
